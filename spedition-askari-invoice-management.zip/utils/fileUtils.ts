
/**
 * Utility to simulate file downloads and data exports
 */

export const downloadMockPDF = (doc: any) => {
  const content = `
    SPEDITION ASKARI GMBH - DOCUMENT EXPORT
    ---------------------------------------
    Reference: ${doc.reference || doc.id}
    Type: ${doc.type || 'Document'}
    Contact: ${doc.contact || doc.name}
    Amount: ${doc.amount} ${doc.currency || 'EUR'}
    Date: ${doc.date}
    Status: ${doc.status}
    
    This is a generated mock PDF content for demonstration.
  `;
  
  const blob = new Blob([content], { type: 'text/plain' });
  const url = window.URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = `${doc.reference || 'document'}.pdf`;
  document.body.appendChild(a);
  a.click();
  window.URL.revokeObjectURL(url);
  document.body.removeChild(a);
};

export const exportToCSV = (data: any[], filename: string) => {
  if (!data || !data.length) return;
  
  const headers = Object.keys(data[0]).join(',');
  const rows = data.map(obj => 
    Object.values(obj).map(val => `"${val}"`).join(',')
  ).join('\n');
  
  const csvContent = `${headers}\n${rows}`;
  const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
  const url = window.URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = `${filename}.csv`;
  document.body.appendChild(a);
  a.click();
  window.URL.revokeObjectURL(url);
  document.body.removeChild(a);
};
