
const express = require('express');
const cors = require('cors');
const { pool } = require('./db');
const bcrypt = require('bcrypt');
const jwt = require('jsonwebtoken');
const nodemailer = require('nodemailer');
const axios = require('axios');
const imaps = require('imap-simple');
const { simpleParser } = require('mailparser');

const app = express();
const PORT = process.env.PORT || 5000;
const JWT_SECRET = 'spedition_askari_secret_key';

app.use(cors());
app.use(express.json({ limit: '15mb' }));

// --- SMTP Configuration ---
const transporter = nodemailer.createTransport({
    host: "smtp.ionos.de",
    port: 587,
    secure: false,
    auth: {
        user: "invoice@askari-transport.de",
        pass: "Askari786768"
    },
    tls: {
        rejectUnauthorized: false, 
        minVersion: 'TLSv1.2'
    }
});

// --- IMAP Configuration ---
const imapConfig = {
    imap: {
        user: 'invoice@askari-transport.de',
        password: 'Askari786768',
        host: 'imap.ionos.de',
        port: 993,
        tls: true,
        authTimeout: 3000
    }
};

// --- IMAP Sync Route ---
app.post('/api/mail/sync-imap', async (req, res) => {
    try {
        console.log("Connecting to IONOS IMAP...");
        const connection = await imaps.connect(imapConfig);
        await connection.openBox('INBOX');

        const searchCriteria = ['ALL'];
        const fetchOptions = {
            bodies: ['HEADER', 'TEXT', ''],
            struct: true
        };

        const messages = await connection.search(searchCriteria, fetchOptions);
        console.log(`Found ${messages.length} messages. Processing latest 10...`);

        // Get latest 10
        const latestMessages = messages.slice(-10).reverse();
        const importedCount = { count: 0 };

        for (const message of latestMessages) {
            const all = message.parts.find(part => part.which === '');
            const id = message.attributes.uid;
            
            // Check if already imported
            const existing = await pool.query('SELECT id FROM documents WHERE source = $1', [`Email-UID-${id}`]);
            if (existing.rows.length > 0) continue;

            const mail = await simpleParser(all.body);
            
            // Look for PDF attachments
            const pdfAttachment = mail.attachments.find(att => att.contentType === 'application/pdf');
            
            if (pdfAttachment || mail.subject.toLowerCase().includes('rechnung') || mail.subject.toLowerCase().includes('invoice')) {
                // Map to document structure
                const reference = mail.subject.substring(0, 100) || `Mail-${id}`;
                const contact = mail.from.text.split('<')[0].trim() || 'Email Sender';
                const date = mail.date ? mail.date.toISOString().split('T')[0] : new Date().toISOString().split('T')[0];
                const amount = 0; // Requires OCR/AI for extraction, defaulting for sync visibility
                
                await pool.query(
                    'INSERT INTO documents (reference, type, contact, amount, currency, status, date, source, uploaded_by) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9)',
                    [reference, 'Bill', contact, amount, 'EUR', 'Pending', date, `Email-UID-${id}`, 'IONOS IMAP Sync']
                );
                importedCount.count++;
            }
        }

        connection.end();
        res.json({ success: true, imported: importedCount.count });

    } catch (error) {
        console.error("IMAP Sync Error:", error);
        res.status(500).json({ error: 'IMAP Sync Failed', details: error.message });
    }
});

// --- Email Routes ---
app.post('/api/mail/send-invoice', async (req, res) => {
  const { to, invoiceNo, clientName, fileName, fileContent } = req.body;
  if (!to) return res.status(400).json({ error: 'Recipient email is required' });
  const mailOptions = {
    from: '"Spedition Askari GmbH" <invoice@askari-transport.de>',
    to: to,
    subject: `Rechnung / Invoice: ${invoiceNo} - Spedition Askari GmbH`,
    text: `Sehr geehrte/r ${clientName},\n\nanbei erhalten Sie die Rechnung Nr. ${invoiceNo}.\n\nMit freundlichen Grüßen,\nIhr Team von Spedition Askari GmbH`,
    attachments: fileContent ? [{ filename: fileName || `Invoice_${invoiceNo}.pdf`, content: fileContent, encoding: 'base64' }] : []
  };
  try {
    const info = await transporter.sendMail(mailOptions);
    res.json({ success: true, messageId: info.messageId });
  } catch (error) {
    res.status(500).json({ error: 'Email Dispatch Failed', details: error.message });
  }
});

// --- User Auth & Docs Routes ---
app.post('/api/auth/signup', async (req, res) => {
  const { name, email, password } = req.body;
  try {
    const userCheck = await pool.query('SELECT * FROM users WHERE email = $1', [email]);
    if (userCheck.rows.length > 0) return res.status(400).json({ error: 'User already exists' });
    const hashedPassword = await bcrypt.hash(password, 10);
    const newUser = await pool.query('INSERT INTO users (name, email, password) VALUES ($1, $2, $3) RETURNING id, name, email', [name, email, hashedPassword]);
    const token = jwt.sign({ id: newUser.rows[0].id }, JWT_SECRET, { expiresIn: '24h' });
    res.status(201).json({ user: newUser.rows[0], token });
  } catch (err) { res.status(500).json({ error: err.message }); }
});

app.post('/api/auth/login', async (req, res) => {
  const { email, password } = req.body;
  try {
    const user = await pool.query('SELECT * FROM users WHERE email = $1', [email]);
    if (user.rows.length === 0) return res.status(401).json({ error: 'User not found' });
    const isValid = await bcrypt.compare(password, user.rows[0].password);
    if (!isValid) return res.status(401).json({ error: 'Invalid password' });
    const token = jwt.sign({ id: user.rows[0].id }, JWT_SECRET, { expiresIn: '24h' });
    res.json({ user: { name: user.rows[0].name, email: user.rows[0].email }, token });
  } catch (err) { res.status(500).json({ error: err.message }); }
});

app.get('/api/documents', async (req, res) => {
  try {
    const docs = await pool.query('SELECT * FROM documents ORDER BY date DESC, created_at DESC');
    res.json(docs.rows);
  } catch (err) { res.status(500).json({ error: err.message }); }
});

app.post('/api/documents', async (req, res) => {
  const { reference, type, contact, amount, currency, status, date, contactInitials, dueDate, uploadedBy } = req.body;
  try {
    const newDoc = await pool.query('INSERT INTO documents (reference, type, contact, amount, currency, status, date, contact_initials, due_date, uploaded_by) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10) RETURNING *', [reference, type, contact, amount, currency, status, date, contact_initials, due_date, uploaded_by]);
    res.status(201).json(newDoc.rows[0]);
  } catch (err) { res.status(500).json({ error: err.message }); }
});

app.put('/api/documents/:id', async (req, res) => {
  const { id } = req.params;
  const updates = req.body;
  const fields = Object.keys(updates);
  const setClause = fields.map((f, i) => `${f} = $${i + 1}`).join(', ');
  const values = Object.values(updates);
  try {
    const result = await pool.query(`UPDATE documents SET ${setClause} WHERE id = $${fields.length + 1} RETURNING *`, [...values, id]);
    res.json(result.rows[0]);
  } catch (err) { res.status(500).json({ error: err.message }); }
});

app.delete('/api/documents/:id', async (req, res) => {
  try {
    await pool.query('DELETE FROM documents WHERE id = $1', [req.params.id]);
    res.json({ message: 'Document deleted' });
  } catch (err) { res.status(500).json({ error: err.message }); }
});

app.get('/api/contacts', async (req, res) => {
  try {
    const contacts = await pool.query('SELECT * FROM contacts ORDER BY name ASC');
    res.json(contacts.rows);
  } catch (err) { res.status(500).json({ error: err.message }); }
});

app.post('/api/contacts', async (req, res) => {
  const { name, email, type, address, tax_id, balance, initials } = req.body;
  try {
    const newContact = await pool.query('INSERT INTO contacts (name, email, type, address, tax_id, balance, initials) VALUES ($1, $2, $3, $4, $5, $6, $7) RETURNING *', [name, email, type, address, tax_id, balance, initials]);
    res.status(201).json(newContact.rows[0]);
  } catch (err) { res.status(500).json({ error: err.message }); }
});

app.delete('/api/contacts/:id', async (req, res) => {
  try {
    await pool.query('DELETE FROM contacts WHERE id = $1', [req.params.id]);
    res.json({ message: 'Contact deleted' });
  } catch (err) { res.status(500).json({ error: err.message }); }
});

app.listen(PORT, () => console.log(`Backend active on port ${PORT}`));
